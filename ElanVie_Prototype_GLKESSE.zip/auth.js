// Mot de passe de test : K@ss#LaG
function login(pwd) { return pwd === 'K@ss#LaG'; }
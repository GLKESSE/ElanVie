document.addEventListener("DOMContentLoaded", function() {
    console.log("Formulaire d'accouchement prêt.");
    // Script de génération de graphique à venir ici
});
